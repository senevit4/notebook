package com.epam.wt.command;

import com.epam.wt.logic.NoteBookLogic;



public final class SortCommand implements Command {

	@Override
	public Response execute(Request request) {
		Response response = new Response();
		NoteBookLogic logic = new NoteBookLogic();
		logic.sortNoteBook();
		return response;
	}

}
