package com.epam.wt.command;

import com.epam.wt.logic.NoteBookLogic;

public final class FindNoteCommand implements Command {

	@Override
	public Response execute(Request request) {
		Response response = new Response();
		NoteBookLogic logic = new NoteBookLogic();
		logic.findNote(request.getIndex());
		return response;
	}

}
