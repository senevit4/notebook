package com.epam.wt.command;


import com.epam.wt.logic.NoteBookLogic;

public final class AddCommand implements Command {

	@Override
	public Response execute(Request request) {
		NoteBookLogic logic=new NoteBookLogic();
		if(request.getNote() != null){
			logic.addNote(request.getNote().getNote(), request.getNote().getDate());
		}
		else if(request.getTopicNote() != null){
			logic.addTopicNote(request.getNote().getNote(), request.getNote().getDate(), request.getTopicNote().getTopic());
		}
		Response response = new Response();
		return response;
	}

}
