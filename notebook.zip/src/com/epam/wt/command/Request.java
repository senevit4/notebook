package com.epam.wt.command;

import java.util.Date;

import com.epam.wt.entity.Note;
import com.epam.wt.entity.TopicNote;

public final class Request {

	private Note note = null;
	private TopicNote topicNote = null;
	private int index = 0;
	private String field = null;
	private Date date = null;

	public Request() {

	}

	public Request(Note note) {
		this.note = note;
	}

	public Request(Date date) {
		this.date = date;
	}

	public Request(int index) {
		this.index = index;
	}

	public Request(int index, String note) {
		this.index = index;
		field = note;
	}

	public Request(String note) {
		field = note;
	}

	public Request(int index, Note note) {
		this.index = index;
		this.note = note;
	}

	public Request(TopicNote topicNote) {
		this.topicNote = topicNote;
	}

	public Note getNote() {
		return note;
	}

	public TopicNote getTopicNote() {
		return topicNote;
	}

	public void setNote(Note note) {
		this.note = note;
	}

	public void setWithTitle(TopicNote topicNote) {
		this.topicNote = topicNote;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getIndex() {
		return index;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getField() {
		return field;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Date getDate() {
		return date;
	}
}
