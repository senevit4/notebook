package com.epam.wt.command;

public interface Command {
	public Response execute(Request request);

}
