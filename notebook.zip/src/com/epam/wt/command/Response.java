package com.epam.wt.command;

import java.util.ArrayList;

import com.epam.wt.entity.Note;
import com.epam.wt.entity.NoteBook;
import com.epam.wt.entity.NoteBookAdapter;

public final class Response {
	private NoteBook notebook;
	private ArrayList<Note> notes;

	public Response() {
		notebook = NoteBookAdapter.getInstance().getNoteBook();
	}

	public Response(ArrayList<Note> notes) {
		this.notes = notes;
	}

	public void setNotebook(NoteBook notebook) {
		this.notebook = notebook;
	}

	public NoteBook getNotebook() {
		return notebook;
	}

	public void setNotes(ArrayList<Note> notes) {
		this.notes = notes;
	}

	public ArrayList<Note> getNotes() {
		return notes;
	}

}
