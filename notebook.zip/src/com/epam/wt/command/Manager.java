package com.epam.wt.command;

public final class Manager {
	private CommandHelper helper = new CommandHelper();

	public Response doRequest(CommandName nc, Request request) {
		Command command = helper.getCommand(nc);
		Response response = command.execute(request);
		return response;
	}

}
