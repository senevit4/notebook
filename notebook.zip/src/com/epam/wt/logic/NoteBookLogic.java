package com.epam.wt.logic;

import java.util.Date;

import com.epam.wt.dao.NoteBookDAOFactory;
import com.epam.wt.dao.NoteBookDao;
import com.epam.wt.entity.Note;

public final class NoteBookLogic {
	NoteBookDao dao = NoteBookDAOFactory.getDAO("memory");

	public void addNote(String note, Date date) {
		dao.addNote(note, date);

	}

	public void addNote(Note note) {
		dao.addNote(note);

	}

	public void addTopicNote(String record, Date date, String topic) {
		dao.addTopicNote(record, date, topic);

	}

	public Note findNote(int index) {
		return dao.findNote(index);

	}

	public void deleteNote(int id) {
		dao.deleteNote(id);
	}

	public int deleteNoteBook() {
		return dao.deleteNoteBook();
	}

	public void showNoteBook() {
		dao.showNoteBook();
	}

	public void sortNoteBook() {
		dao.sortNoteBook();
	}
}
