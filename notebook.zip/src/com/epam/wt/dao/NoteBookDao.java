package com.epam.wt.dao;

import java.util.Date;

import com.epam.wt.entity.Note;

public interface NoteBookDao {

	void addNote(Note note);

	void addNote(String record, Date date);

	void addTopicNote(String record, Date date, String topic);

	Note findNote(int id);

	void deleteNote(int id);

	int deleteNoteBook();

	void sortNoteBook();

	void showNoteBook();

}
