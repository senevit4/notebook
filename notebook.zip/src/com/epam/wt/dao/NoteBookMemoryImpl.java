package com.epam.wt.dao;

import java.util.Collections;
import java.util.Date;

import com.epam.wt.entity.Note;
import com.epam.wt.entity.NoteBook;
import com.epam.wt.entity.NoteBookAdapter;
import com.epam.wt.entity.TopicNote;

public final class NoteBookMemoryImpl implements NoteBookDao {
	NoteBook noteBook = NoteBookAdapter.getInstance().getNoteBook();

	public void addNote(String name, Date date) {
		Note note = new Note();
		note.setDate(date);
		note.setNote(name);
		noteBook.add(note);
	}

	public void addNote(Note note) {

		noteBook.add(note);
	}

	public Note findNote(int id) {

		return noteBook.getNoteBook().get(id);
	}

	@Override
	public void deleteNote(int id) {

		noteBook.deleteNote(id);
	}

	@Override
	public void addTopicNote(String record, Date date, String topic) {
		TopicNote note = new TopicNote();
		note.setDate(date);
		note.setNote(record);
		note.setTopic(topic);

		noteBook.add(note);

	}

	@Override
	public int deleteNoteBook() {

		return noteBook.deleteNotebook();

	}

	@Override
	public void showNoteBook() {

		System.out.println(noteBook.getNoteBook().toString());

	}

	@Override
	public void sortNoteBook() {

		NoteBookComparator comparator = new NoteBookComparator();
		Collections.sort(noteBook.getNoteBook(), comparator);
	}

}
