package com.epam.wt.dao;

import java.util.Date;

import com.epam.wt.entity.Note;

public final class NoteBookFileImpl implements NoteBookDao {

	@Override
	public void addNote(Note note) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addNote(String record, Date date) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addTopicNote(String record, Date date, String topic) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Note findNote(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteNote(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int deleteNoteBook() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void showNoteBook() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sortNoteBook() {
		// TODO Auto-generated method stub
		
	}

}
