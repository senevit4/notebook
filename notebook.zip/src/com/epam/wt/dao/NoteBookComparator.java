package com.epam.wt.dao;

import java.util.Comparator;

import com.epam.wt.entity.Note;

public final class NoteBookComparator implements Comparator<Note> {

	@Override
	public int compare(Note note1, Note note2) {
		if (note1.getDate().compareTo(note2.getDate()) == 0) {
			return 0;
		}
		if (note1.getDate().compareTo(note2.getDate()) > 0) {
			return 1;
		}
		if (note1.getDate().compareTo(note2.getDate()) < 0) {
			return -1;
		}
		return 0;
	}

}
