package com.epam.wt.dao;

public final class NoteBookDAOFactory {
	private static NoteBookMemoryImpl nbm = new NoteBookMemoryImpl();
	private static NoteBookFileImpl nbf = new NoteBookFileImpl();
	private static DaoEnum type = DaoEnum.getType("memory");

	public static NoteBookDao getDAO(String type) {
		switch (NoteBookDAOFactory.type) {
		case USING_MEMORY:
			return nbm;
		case USING_FILE:
			return nbf;
		}
		return null;
	}

}
