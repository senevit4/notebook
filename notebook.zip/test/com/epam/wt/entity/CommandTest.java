package com.epam.wt.entity;

import org.testng.annotations.Test;

public class CommandTest {
	@Test
	public void commandTest() {

	}
}
